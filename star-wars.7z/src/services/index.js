import SwapiService from './swapi-service'

export default SwapiService;