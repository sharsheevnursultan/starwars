import Person from "./person";

export default Person;
