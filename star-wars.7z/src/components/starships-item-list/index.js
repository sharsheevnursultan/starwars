import StarshipsItemList from "./starships-item-list";

export default StarshipsItemList;
